#!/usr/bin/env python3
"""
HKJC AI Betting Lab — Replit Dashboard Server
==============================================
完整自包含的 Dashboard 服務器。
放上 Replit 後直接 Run 就能看到所有數據。

架構：
  GET  /              → Dashboard 主頁（深藍色 8 頁面）
  GET  /api/matches   → 所有比賽 JSON
  GET  /api/stats     → 系統統計
  GET  /api/agents    → 角色列表 + 錢包
  GET  /api/leaderboard → 排行榜
"""

import os
import json
import sqlite3
from datetime import datetime
from flask import Flask, jsonify, Response

app = Flask(__name__, static_folder="static", static_url_path="/static")

DB_PATH = os.path.join(os.path.dirname(__file__), "betting_lab.db")


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


# ══════════════════════════════════════════════════════════════
#  API
# ══════════════════════════════════════════════════════════════

@app.route("/api/stats")
def api_stats():
    conn = get_db()
    stats = {}
    for t in ["matches", "results", "agents", "wallets", "bets", "odds_snapshots"]:
        try:
            stats[t] = conn.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0]
        except Exception:
            stats[t] = 0

    # 比賽狀態分佈
    rows = conn.execute("SELECT status, COUNT(*) as cnt FROM matches GROUP BY status").fetchall()
    stats["match_status"] = {r["status"]: r["cnt"] for r in rows}

    conn.close()
    return jsonify(stats)


@app.route("/api/matches")
def api_matches():
    status = __import__("flask").request.args.get("status")
    conn = get_db()
    if status:
        rows = conn.execute("SELECT * FROM matches WHERE status = ? ORDER BY kickoff", (status,)).fetchall()
    else:
        rows = conn.execute("SELECT * FROM matches ORDER BY kickoff").fetchall()
    data = [dict(r) for r in rows]
    conn.close()
    return jsonify({"count": len(data), "matches": data})


@app.route("/api/agents")
def api_agents():
    conn = get_db()
    rows = conn.execute("""
        SELECT a.agent_id, a.name, a.nickname, a.base_mbti, a.age, a.occupation,
               w.balance, w.total_bets, w.total_wins, w.total_pnl,
               w.win_streak, w.lose_streak, w.biggest_win, w.biggest_loss,
               s.mood, s.confidence, s.risk_appetite, s.anxiety, s.current_energy
        FROM agents a
        LEFT JOIN wallets w ON a.agent_id = w.agent_id
        LEFT JOIN agent_states s ON a.agent_id = s.agent_id
    """).fetchall()
    agents = []
    for r in rows:
        agents.append({
            "id": r["agent_id"],
            "name": r["name"],
            "nickname": r["nickname"],
            "mbti": r["base_mbti"],
            "age": r["age"],
            "occupation": r["occupation"],
            "balance": r["balance"] or 10000,
            "total_bets": r["total_bets"] or 0,
            "total_wins": r["total_wins"] or 0,
            "total_pnl": r["total_pnl"] or 0,
            "win_streak": r["win_streak"] or 0,
            "lose_streak": r["lose_streak"] or 0,
            "biggest_win": r["biggest_win"] or 0,
            "biggest_loss": r["biggest_loss"] or 0,
            "mood": r["mood"] or 0,
            "confidence": r["confidence"] or 0,
            "risk_appetite": r["risk_appetite"] or 0.5,
            "anxiety": r["anxiety"] or 0,
            "energy": r["current_energy"] or 100,
        })
    conn.close()
    return jsonify({"count": len(agents), "agents": agents})


@app.route("/api/leaderboard")
def api_leaderboard():
    conn = get_db()
    try:
        rows = conn.execute("SELECT * FROM v_leaderboard").fetchall()
        data = [dict(r) for r in rows]
    except Exception:
        data = []
    conn.close()
    return jsonify({"count": len(data), "leaderboard": data})


@app.route("/api/upcoming")
def api_upcoming():
    conn = get_db()
    rows = conn.execute("""
        SELECT match_id, home, away, tournament, kickoff, had_h, had_d, had_a
        FROM matches WHERE status = 'upcoming' ORDER BY kickoff LIMIT 50
    """).fetchall()
    data = [dict(r) for r in rows]
    conn.close()
    return jsonify({"count": len(data), "matches": data})


# ══════════════════════════════════════════════════════════════
#  Dashboard HTML
# ══════════════════════════════════════════════════════════════

@app.route("/")
def dashboard():
    conn = get_db()

    # 統計
    total_matches = conn.execute("SELECT COUNT(*) FROM matches").fetchone()[0]
    upcoming = conn.execute("SELECT COUNT(*) FROM matches WHERE status='upcoming'").fetchone()[0]
    finished = conn.execute("SELECT COUNT(*) FROM matches WHERE status='finished'").fetchone()[0]
    live = conn.execute("SELECT COUNT(*) FROM matches WHERE status='live'").fetchone()[0]
    total_agents = conn.execute("SELECT COUNT(*) FROM agents").fetchone()[0]
    total_bets = conn.execute("SELECT COUNT(*) FROM bets").fetchone()[0]

    # Agents
    agents = conn.execute("""
        SELECT a.agent_id, a.name, a.nickname, a.base_mbti, a.occupation,
               w.balance, w.total_bets, w.total_wins, w.total_pnl,
               s.mood, s.confidence, s.risk_appetite, s.current_energy
        FROM agents a
        LEFT JOIN wallets w ON a.agent_id = w.agent_id
        LEFT JOIN agent_states s ON a.agent_id = s.agent_id
        ORDER BY w.balance DESC
    """).fetchall()

    # Upcoming matches
    matches = conn.execute("""
        SELECT match_id, home, away, tournament, kickoff, had_h, had_d, had_a
        FROM matches WHERE status = 'upcoming' ORDER BY kickoff LIMIT 30
    """).fetchall()

    # Finished matches
    finished_matches = conn.execute("""
        SELECT match_id, home, away, tournament, home_goals, away_goals, had_result
        FROM matches WHERE status = 'finished' ORDER BY updated_at DESC LIMIT 20
    """).fetchall()

    conn.close()

    # 生成 HTML
    html = f"""<!DOCTYPE html>
<html lang="zh-HK">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>HKJC AI Betting Lab</title>
<style>
*{{margin:0;padding:0;box-sizing:border-box}}
body{{font-family:-apple-system,BlinkMacSystemFont,'Microsoft YaHei',sans-serif;background:#0a1128;color:#e0e0e0;min-height:100vh}}
.header{{background:linear-gradient(135deg,#0d1b2a,#1b2838);padding:24px;text-align:center;border-bottom:2px solid #d4af37}}
h1{{color:#d4af37;font-size:1.8em;margin-bottom:4px}}
.subtitle{{color:#888;font-size:.9em}}
.container{{max-width:1200px;margin:0 auto;padding:20px}}
.tabs{{display:flex;gap:4px;margin-bottom:20px;flex-wrap:wrap}}
.tab{{background:#1a2252;border:1px solid #2a3a6a;border-radius:8px 8px 0 0;padding:10px 18px;cursor:pointer;color:#888;font-size:.85em;transition:all .2s}}
.tab.active,.tab:hover{{background:#2a3a6a;color:#d4af37;border-color:#d4af37}}
.tab-content{{display:none}}.tab-content.active{{display:block}}
.stats-row{{display:flex;gap:12px;margin-bottom:24px;flex-wrap:wrap}}
.stat-card{{background:#1a2252;border:1px solid #2a3a6a;border-radius:12px;padding:16px 20px;flex:1;min-width:120px;text-align:center}}
.stat-val{{font-size:1.6em;font-weight:700;color:#d4af37}}
.stat-label{{font-size:.78em;color:#888;margin-top:4px}}
.agent-grid{{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:14px}}
.agent-card{{background:#1a2252;border:1px solid #2a3a6a;border-radius:12px;padding:16px}}
.agent-name{{font-size:1.1em;font-weight:700;color:#e0e0e0}}
.agent-meta{{font-size:.8em;color:#888;margin:4px 0 12px}}
.agent-stats{{display:flex;gap:6px;flex-wrap:wrap}}
.agent-stat{{background:#0d1b3e;border-radius:6px;padding:6px 10px;text-align:center;flex:1;min-width:60px}}
.agent-stat .v{{font-size:.95em;font-weight:600;color:#d4af37}}
.agent-stat .l{{font-size:.68em;color:#888;margin-top:2px}}
.emo-bar{{height:4px;background:#0d1b3e;border-radius:2px;margin-top:8px;overflow:hidden}}
.emo-fill{{height:100%;border-radius:2px}}
table{{width:100%;border-collapse:collapse;font-size:.85em}}
th{{text-align:left;color:#888;font-weight:500;padding:8px 10px;border-bottom:1px solid #2a3a6a;font-size:.8em}}
td{{padding:8px 10px;border-bottom:1px solid #1a2a4a}}
.odds{{color:#d4af37;font-weight:600}}
.pos{{color:#81c784}}.neg{{color:#ef9a9a}}
.badge{{display:inline-block;padding:2px 8px;border-radius:4px;font-size:.75em;font-weight:600}}
.badge-h{{background:#1b5e20;color:#a5d6a7}}.badge-d{{background:#4a148c;color:#ce93d8}}.badge-a{{background:#b71c1c;color:#ef9a9a}}
.section{{background:#1a2252;border:1px solid #2a3a6a;border-radius:12px;padding:16px;margin-bottom:16px}}
.section h2{{color:#d4af37;font-size:.95em;margin-bottom:12px}}
.footer{{text-align:center;color:#444;font-size:.75em;padding:20px;border-top:1px solid #1a2a4a;margin-top:24px}}
</style>
</head>
<body>
<div class="header">
<h1>HKJC AI Betting Lab</h1>
<div class="subtitle">AI \u89D2\u8272\u81EA\u4E3B\u6295\u6CE8\u5BE6\u9A57\u5BA4 | {total_matches} \u5834\u8CFD\u4E8B | {total_agents} \u4F4D AI \u89D2\u8272</div>
</div>
<div class="container">

<div class="tabs">
<div class="tab active" onclick="showTab('overview')">\u7E3D\u89BD</div>
<div class="tab" onclick="showTab('agents')">\u89D2\u8272</div>
<div class="tab" onclick="showTab('upcoming')">\u672A\u958B\u8CFD ({upcoming})</div>
<div class="tab" onclick="showTab('finished')">\u5DF2\u5B8C\u7D50 ({finished})</div>
</div>

<!-- Overview Tab -->
<div id="tab-overview" class="tab-content active">
<div class="stats-row">
<div class="stat-card"><div class="stat-val">{total_matches}</div><div class="stat-label">\u7E3D\u8CFD\u4E8B</div></div>
<div class="stat-card"><div class="stat-val">{upcoming}</div><div class="stat-label">\u672A\u958B\u8CFD</div></div>
<div class="stat-card"><div class="stat-val">{live}</div><div class="stat-label">\u5373\u5834\u9032\u884C</div></div>
<div class="stat-card"><div class="stat-val">{finished}</div><div class="stat-label">\u5DF2\u5B8C\u7D50</div></div>
<div class="stat-card"><div class="stat-val">{total_agents}</div><div class="stat-label">AI \u89D2\u8272</div></div>
<div class="stat-card"><div class="stat-val">{total_bets}</div><div class="stat-label">\u7E3D\u6295\u6CE8</div></div>
</div>

<div class="section">
<h2>\u5373\u5C07\u958B\u8CFD</h2>
<table>
<tr><th>\u7DE8\u865F</th><th>\u4E3B\u968A</th><th></th><th>\u5BA2\u968A</th><th>\u806F\u8CFD</th><th>\u958B\u8CFD</th><th>\u4E3B\u52DD</th><th>\u548C</th><th>\u5BA2\u52DD</th></tr>
"""
    for m in matches[:15]:
        ko = (m["kickoff"] or "")[:16].replace("T", " ")
        hh = f'{m["had_h"]:.2f}' if m["had_h"] else "-"
        hd = f'{m["had_d"]:.2f}' if m["had_d"] else "-"
        ha = f'{m["had_a"]:.2f}' if m["had_a"] else "-"
        html += f'<tr><td>{m["match_id"]}</td><td>{m["home"]}</td><td style="color:#555">vs</td><td>{m["away"]}</td><td style="color:#888">{(m["tournament"] or "")[:12]}</td><td style="color:#888">{ko}</td><td class="odds">{hh}</td><td class="odds">{hd}</td><td class="odds">{ha}</td></tr>\n'

    html += """</table></div></div>

<!-- Agents Tab -->
<div id="tab-agents" class="tab-content">
<div class="agent-grid">
"""
    emojis = {"ESTP": "\uD83D\uDC77", "ENFP": "\uD83D\uDCBC", "ISTJ": "\uD83C\uDFE5", "INFJ": "\uD83D\uDCDA"}
    for a in agents:
        bal = a["balance"] or 10000
        pnl = (a["total_pnl"] or 0)
        pnl_cls = "pos" if pnl >= 0 else "neg"
        pnl_sign = "+" if pnl >= 0 else ""
        tb = a["total_bets"] or 0
        tw = a["total_wins"] or 0
        wr = round(tw / tb * 100, 1) if tb > 0 else 0
        emoji = emojis.get(a["base_mbti"], "\uD83D\uDC64")
        mood = a["mood"] or 0
        conf = a["confidence"] or 0
        energy = a["current_energy"] or 100
        html += f"""<div class="agent-card">
<div style="display:flex;align-items:center;gap:10px;margin-bottom:10px">
<span style="font-size:2em">{emoji}</span>
<div>
<div class="agent-name">{a["name"]}</div>
<div class="agent-meta">{a["base_mbti"]} | {a["occupation"] or ""} | {a["nickname"] or ""}</div>
</div>
<div style="margin-left:auto;text-align:right">
<div style="font-size:1.2em;font-weight:700;color:#d4af37">${bal:,.0f}</div>
<div class="{pnl_cls}" style="font-size:.85em">{pnl_sign}${pnl:,.0f}</div>
</div>
</div>
<div class="agent-stats">
<div class="agent-stat"><div class="v">{tb}</div><div class="l">\u4E0B\u6CE8</div></div>
<div class="agent-stat"><div class="v">{tw}</div><div class="l">\u52DD</div></div>
<div class="agent-stat"><div class="v">{wr}%</div><div class="l">\u52DD\u7387</div></div>
<div class="agent-stat"><div class="v">{int(energy)}</div><div class="l">\u7CBE\u529B</div></div>
</div>
<div style="margin-top:10px;font-size:.75em;color:#666">
\u5FC3\u60C5 <div class="emo-bar"><div class="emo-fill" style="width:{max(0,min(100,mood*100))}%;background:#4fc3f7"></div></div>
\u81EA\u4FE1 <div class="emo-bar"><div class="emo-fill" style="width:{max(0,min(100,conf*100))}%;background:#81c784"></div></div>
</div>
</div>
"""

    html += """</div></div>

<!-- Upcoming Tab -->
<div id="tab-upcoming" class="tab-content">
<div class="section"><h2>\u6240\u6709\u672A\u958B\u8CFD\u8CFD\u4E8B</h2>
<table>
<tr><th>\u7DE8\u865F</th><th>\u4E3B\u968A</th><th></th><th>\u5BA2\u968A</th><th>\u806F\u8CFD</th><th>\u958B\u8CFD</th><th>\u4E3B\u52DD</th><th>\u548C</th><th>\u5BA2\u52DD</th></tr>
"""
    for m in matches:
        ko = (m["kickoff"] or "")[:16].replace("T", " ")
        hh = f'{m["had_h"]:.2f}' if m["had_h"] else "-"
        hd = f'{m["had_d"]:.2f}' if m["had_d"] else "-"
        ha = f'{m["had_a"]:.2f}' if m["had_a"] else "-"
        html += f'<tr><td>{m["match_id"]}</td><td>{m["home"]}</td><td style="color:#555">vs</td><td>{m["away"]}</td><td style="color:#888">{(m["tournament"] or "")[:12]}</td><td style="color:#888">{ko}</td><td class="odds">{hh}</td><td class="odds">{hd}</td><td class="odds">{ha}</td></tr>\n'

    html += """</table></div></div>

<!-- Finished Tab -->
<div id="tab-finished" class="tab-content">
<div class="section"><h2>\u5DF2\u5B8C\u7D50\u8CFD\u4E8B</h2>
<table>
<tr><th>\u7DE8\u865F</th><th>\u4E3B\u968A</th><th>\u6BD4\u5206</th><th>\u5BA2\u968A</th><th>\u806F\u8CFD</th><th>\u7D50\u679C</th></tr>
"""
    for m in finished_matches:
        hg = m["home_goals"] if m["home_goals"] is not None else "?"
        ag = m["away_goals"] if m["away_goals"] is not None else "?"
        result = m["had_result"] or ""
        badge_cls = {"H": "badge-h", "D": "badge-d", "A": "badge-a"}.get(result, "")
        result_text = {"H": "\u4E3B\u52DD", "D": "\u548C\u5C40", "A": "\u5BA2\u52DD"}.get(result, "-")
        html += f'<tr><td>{m["match_id"]}</td><td>{m["home"]}</td><td style="font-weight:700">{hg}:{ag}</td><td>{m["away"]}</td><td style="color:#888">{(m["tournament"] or "")[:12]}</td><td><span class="badge {badge_cls}">{result_text}</span></td></tr>\n'

    html += f"""</table></div></div>

</div>

<div class="footer">
HKJC AI Betting Lab | \u6578\u64DA\u66F4\u65B0: {datetime.now().strftime('%Y-%m-%d %H:%M')} | \u7D14\u5C55\u793A\u7528\u9014<br>
\u00A9 2026 AI Betting Lab
</div>

<script>
function showTab(name) {{
  document.querySelectorAll('.tab-content').forEach(el => el.classList.remove('active'));
  document.querySelectorAll('.tab').forEach(el => el.classList.remove('active'));
  document.getElementById('tab-' + name).classList.add('active');
  event.target.classList.add('active');
}}
</script>
</body></html>"""

    return Response(html, content_type="text/html; charset=utf-8")


# ══════════════════════════════════════════════════════════════
#  啟動
# ══════════════════════════════════════════════════════════════

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    print(f"\nHKJC AI Betting Lab Dashboard")
    print(f"http://localhost:{port}")
    print(f"DB: {DB_PATH} ({os.path.getsize(DB_PATH) / 1024:.0f}KB)")
    app.run(host="0.0.0.0", port=port, threaded=True)
