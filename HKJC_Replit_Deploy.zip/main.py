#!/usr/bin/env python3
"""
HKJC AI Betting Lab — Replit Dashboard Server (Live Sync)
==========================================================
兩種模式：
  1. 靜態模式 — 直接從 SQLite 讀數據展示（上傳 ZIP 後即可用）
  2. 即時模式 — 本地系統通過 POST /push 推送更新，Dashboard 自動刷新

API：
  GET  /              → Dashboard 主頁
  GET  /api/stats     → 系統統計
  GET  /api/matches   → 所有比賽
  GET  /api/agents    → 角色列表
  GET  /api/leaderboard → 排行榜
  POST /push          → 接收本地推送（需 Bearer token）
  GET  /api/stream    → SSE 即時更新流
"""

import os
import json
import queue
import sqlite3
import threading
from datetime import datetime
from flask import Flask, request, jsonify, Response

app = Flask(__name__)

DB_PATH = os.path.join(os.path.dirname(__file__), "betting_lab.db")
SECRET_KEY = os.environ.get("HKJC_SECRET_KEY", "")

# ── 即時推送快照（內存）──
_data_lock = threading.Lock()
_latest_push = None        # 最近一次 push 的 JSON 快照
_last_push_at = None       # 最近一次 push 時間

# ── SSE 訂閱者 ──
_sse_lock = threading.Lock()
_sse_subscribers = []


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def sse_broadcast(data):
    msg = json.dumps(data, ensure_ascii=False)
    with _sse_lock:
        dead = []
        for q in _sse_subscribers:
            try:
                q.put_nowait(msg)
            except queue.Full:
                dead.append(q)
        for q in dead:
            _sse_subscribers.remove(q)


# ══════════════════════════════════════════════════════════════
#  POST /push — 接收本地推送
# ══════════════════════════════════════════════════════════════

@app.route("/push", methods=["POST"])
def push_data():
    """本地系統推送最新快照 — 需 Bearer token"""
    global _latest_push, _last_push_at

    if SECRET_KEY:
        auth = request.headers.get("Authorization", "")
        if not auth.startswith("Bearer ") or auth[7:] != SECRET_KEY:
            return jsonify({"error": "Unauthorized"}), 401

    try:
        payload = request.get_json(force=True)
        if not payload:
            return jsonify({"error": "Empty payload"}), 400

        payload["received_at"] = datetime.now().isoformat()

        with _data_lock:
            _latest_push = payload
            _last_push_at = datetime.now()

        sse_broadcast({"type": "data_push", "updated_at": payload.get("updated_at")})

        agents_count = len(payload.get("agents", []))
        matches_total = payload.get("matches", {}).get("total", 0)
        print(f"[Push] Received: {agents_count} agents, {matches_total} matches")
        return jsonify({"ok": True, "received_at": payload["received_at"]}), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ══════════════════════════════════════════════════════════════
#  SSE 即時更新流
# ══════════════════════════════════════════════════════════════

@app.route("/api/stream")
def sse_stream():
    def generate():
        q = queue.Queue(maxsize=50)
        with _sse_lock:
            _sse_subscribers.append(q)
        try:
            yield f"data: {json.dumps({'type': 'connected'})}\n\n"
            while True:
                try:
                    msg = q.get(timeout=25)
                    yield f"data: {msg}\n\n"
                except queue.Empty:
                    yield ": heartbeat\n\n"
        finally:
            with _sse_lock:
                if q in _sse_subscribers:
                    _sse_subscribers.remove(q)

    return Response(generate(),
                    content_type="text/event-stream",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


# ══════════════════════════════════════════════════════════════
#  API
# ══════════════════════════════════════════════════════════════

@app.route("/api/stats")
def api_stats():
    conn = get_db()
    stats = {}
    for t in ["matches", "results", "agents", "wallets", "bets", "odds_snapshots"]:
        try:
            stats[t] = conn.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0]
        except Exception:
            stats[t] = 0
    rows = conn.execute("SELECT status, COUNT(*) as cnt FROM matches GROUP BY status").fetchall()
    stats["match_status"] = {r["status"]: r["cnt"] for r in rows}
    with _data_lock:
        stats["has_live_push"] = _latest_push is not None
        stats["last_push_at"] = _last_push_at.isoformat() if _last_push_at else None
    conn.close()
    return jsonify(stats)


@app.route("/api/matches")
def api_matches():
    status = request.args.get("status")
    conn = get_db()
    if status:
        rows = conn.execute("SELECT * FROM matches WHERE status = ? ORDER BY kickoff", (status,)).fetchall()
    else:
        rows = conn.execute("SELECT * FROM matches ORDER BY kickoff").fetchall()
    data = [dict(r) for r in rows]
    conn.close()
    return jsonify({"count": len(data), "matches": data})


@app.route("/api/agents")
def api_agents():
    # 優先用 live push 數據
    with _data_lock:
        if _latest_push and _latest_push.get("agents"):
            return jsonify({"count": len(_latest_push["agents"]), "agents": _latest_push["agents"], "source": "live_push"})

    conn = get_db()
    rows = conn.execute("""
        SELECT a.agent_id, a.name, a.nickname, a.base_mbti, a.age, a.occupation,
               w.balance, w.total_bets, w.total_wins, w.total_pnl,
               s.mood, s.confidence, s.risk_appetite, s.current_energy
        FROM agents a
        LEFT JOIN wallets w ON a.agent_id = w.agent_id
        LEFT JOIN agent_states s ON a.agent_id = s.agent_id
    """).fetchall()
    agents = [{
        "id": r["agent_id"], "name": r["name"], "nickname": r["nickname"],
        "mbti": r["base_mbti"], "occupation": r["occupation"],
        "balance": r["balance"] or 10000, "total_bets": r["total_bets"] or 0,
        "total_wins": r["total_wins"] or 0, "total_pnl": r["total_pnl"] or 0,
        "mood": r["mood"] or 0, "confidence": r["confidence"] or 0,
        "energy": r["current_energy"] or 100,
    } for r in rows]
    conn.close()
    return jsonify({"count": len(agents), "agents": agents, "source": "sqlite"})


@app.route("/api/leaderboard")
def api_leaderboard():
    conn = get_db()
    try:
        rows = conn.execute("SELECT * FROM v_leaderboard").fetchall()
        data = [dict(r) for r in rows]
    except Exception:
        data = []
    conn.close()
    return jsonify({"count": len(data), "leaderboard": data})


# ══════════════════════════════════════════════════════════════
#  Dashboard HTML
# ══════════════════════════════════════════════════════════════

@app.route("/")
def dashboard():
    conn = get_db()

    total_matches = conn.execute("SELECT COUNT(*) FROM matches").fetchone()[0]
    upcoming = conn.execute("SELECT COUNT(*) FROM matches WHERE status='upcoming'").fetchone()[0]
    finished = conn.execute("SELECT COUNT(*) FROM matches WHERE status='finished'").fetchone()[0]
    live = conn.execute("SELECT COUNT(*) FROM matches WHERE status='live'").fetchone()[0]
    total_agents = conn.execute("SELECT COUNT(*) FROM agents").fetchone()[0]
    total_bets = conn.execute("SELECT COUNT(*) FROM bets").fetchone()[0]

    # 優先用 live push 的數據
    with _data_lock:
        push_agents = _latest_push.get("agents", []) if _latest_push else []
        push_events = _latest_push.get("events", []) if _latest_push else []
        push_matches = _latest_push.get("matches", {}).get("preevent", []) if _latest_push else []
        push_time = _last_push_at.strftime('%H:%M:%S') if _last_push_at else None

    agents = conn.execute("""
        SELECT a.agent_id, a.name, a.nickname, a.base_mbti, a.occupation,
               w.balance, w.total_bets, w.total_wins, w.total_pnl,
               s.mood, s.confidence, s.risk_appetite, s.current_energy
        FROM agents a LEFT JOIN wallets w ON a.agent_id = w.agent_id
        LEFT JOIN agent_states s ON a.agent_id = s.agent_id
        ORDER BY w.balance DESC
    """).fetchall()

    matches = conn.execute("""
        SELECT match_id, home, away, tournament, kickoff, had_h, had_d, had_a
        FROM matches WHERE status = 'upcoming' ORDER BY kickoff LIMIT 30
    """).fetchall()

    finished_matches = conn.execute("""
        SELECT match_id, home, away, tournament, home_goals, away_goals, had_result
        FROM matches WHERE status = 'finished' ORDER BY updated_at DESC LIMIT 20
    """).fetchall()

    conn.close()

    # 如果有 push 的賽事數據，用 push 的覆蓋（真實賠率）
    if push_matches:
        # 轉換 push 格式為 matches 格式（統一 key 名）
        matches = []
        for pm in push_matches:
            matches.append({
                "match_id": pm.get("match_id", ""),
                "home": pm.get("home", ""),
                "away": pm.get("away", ""),
                "tournament": pm.get("league", ""),
                "kickoff": pm.get("kickoff", ""),
                "had_h": pm.get("hadH"),
                "had_d": pm.get("hadD"),
                "had_a": pm.get("hadA"),
            })
        upcoming = len(matches)

    # 如果有 live push，用 push 的 agent 數據覆蓋
    if push_agents:
        agent_data = push_agents
    else:
        agent_data = [dict(a) for a in agents]

    # ── 生成 HTML ──
    live_dot = '<span style="display:inline-block;width:8px;height:8px;background:#4caf50;border-radius:50%;margin-right:5px;animation:pulse 2s infinite"></span>' if push_time else ''
    sync_info = f'{live_dot}即時同步中 (上次: {push_time})' if push_time else '靜態模式 (等待本地推送)'

    html = f"""<!DOCTYPE html>
<html lang="zh-HK">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>HKJC AI Betting Lab</title>
<style>
*{{margin:0;padding:0;box-sizing:border-box}}
body{{font-family:-apple-system,BlinkMacSystemFont,'Microsoft YaHei',sans-serif;background:#0a1128;color:#e0e0e0;min-height:100vh}}
@keyframes pulse{{0%,100%{{opacity:1}}50%{{opacity:.3}}}}
.header{{background:linear-gradient(135deg,#0d1b2a,#1b2838);padding:24px;text-align:center;border-bottom:2px solid #d4af37}}
h1{{color:#d4af37;font-size:1.8em;margin-bottom:4px}}
.subtitle{{color:#888;font-size:.9em}}
.sync-bar{{background:#0d1b2a;padding:6px 16px;text-align:center;font-size:.78em;color:#666;border-bottom:1px solid #1a2a4a}}
.container{{max-width:1200px;margin:0 auto;padding:20px}}
.tabs{{display:flex;gap:4px;margin-bottom:20px;flex-wrap:wrap}}
.tab{{background:#1a2252;border:1px solid #2a3a6a;border-radius:8px 8px 0 0;padding:10px 18px;cursor:pointer;color:#888;font-size:.85em;transition:all .2s}}
.tab.active,.tab:hover{{background:#2a3a6a;color:#d4af37;border-color:#d4af37}}
.tab-content{{display:none}}.tab-content.active{{display:block}}
.stats-row{{display:flex;gap:12px;margin-bottom:24px;flex-wrap:wrap}}
.stat-card{{background:#1a2252;border:1px solid #2a3a6a;border-radius:12px;padding:16px 20px;flex:1;min-width:120px;text-align:center}}
.stat-val{{font-size:1.6em;font-weight:700;color:#d4af37}}
.stat-label{{font-size:.78em;color:#888;margin-top:4px}}
.agent-grid{{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:14px}}
.agent-card{{background:#1a2252;border:1px solid #2a3a6a;border-radius:12px;padding:16px}}
.agent-name{{font-size:1.1em;font-weight:700;color:#e0e0e0}}
.agent-meta{{font-size:.8em;color:#888;margin:4px 0 12px}}
.agent-stats{{display:flex;gap:6px;flex-wrap:wrap}}
.agent-stat{{background:#0d1b3e;border-radius:6px;padding:6px 10px;text-align:center;flex:1;min-width:60px}}
.agent-stat .v{{font-size:.95em;font-weight:600;color:#d4af37}}
.agent-stat .l{{font-size:.68em;color:#888;margin-top:2px}}
.emo-bar{{height:4px;background:#0d1b3e;border-radius:2px;margin-top:8px;overflow:hidden}}
.emo-fill{{height:100%;border-radius:2px}}
table{{width:100%;border-collapse:collapse;font-size:.85em}}
th{{text-align:left;color:#888;font-weight:500;padding:8px 10px;border-bottom:1px solid #2a3a6a;font-size:.8em}}
td{{padding:8px 10px;border-bottom:1px solid #1a2a4a}}
.odds{{color:#d4af37;font-weight:600}}
.pos{{color:#81c784}}.neg{{color:#ef9a9a}}
.badge{{display:inline-block;padding:2px 8px;border-radius:4px;font-size:.75em;font-weight:600}}
.badge-h{{background:#1b5e20;color:#a5d6a7}}.badge-d{{background:#4a148c;color:#ce93d8}}.badge-a{{background:#b71c1c;color:#ef9a9a}}
.section{{background:#1a2252;border:1px solid #2a3a6a;border-radius:12px;padding:16px;margin-bottom:16px}}
.section h2{{color:#d4af37;font-size:.95em;margin-bottom:12px}}
.event-log{{font-size:.8em;max-height:200px;overflow-y:auto}}
.event-row{{padding:4px 0;border-bottom:1px solid #1a2a4a;color:#aaa}}
.event-ts{{color:#555;font-size:.85em;margin-right:8px}}
.footer{{text-align:center;color:#444;font-size:.75em;padding:20px;border-top:1px solid #1a2a4a;margin-top:24px}}
</style>
</head>
<body>
<div class="header">
<h1>HKJC AI Betting Lab</h1>
<div class="subtitle">AI 角色自主投注實驗室 | {total_matches} 場賽事 | {total_agents} 位 AI 角色</div>
</div>
<div class="sync-bar" id="sync-bar">{sync_info}</div>
<div class="container">

<div class="tabs">
<div class="tab active" onclick="showTab('overview')">總覽</div>
<div class="tab" onclick="showTab('agents')">角色</div>
<div class="tab" onclick="showTab('upcoming')">未開賽 ({upcoming})</div>
<div class="tab" onclick="showTab('finished')">已完結 ({finished})</div>
</div>

<!-- Overview -->
<div id="tab-overview" class="tab-content active">
<div class="stats-row">
<div class="stat-card"><div class="stat-val">{total_matches}</div><div class="stat-label">總賽事</div></div>
<div class="stat-card"><div class="stat-val">{upcoming}</div><div class="stat-label">未開賽</div></div>
<div class="stat-card"><div class="stat-val">{live}</div><div class="stat-label">即場</div></div>
<div class="stat-card"><div class="stat-val">{finished}</div><div class="stat-label">已完結</div></div>
<div class="stat-card"><div class="stat-val">{total_agents}</div><div class="stat-label">AI 角色</div></div>
<div class="stat-card"><div class="stat-val">{total_bets}</div><div class="stat-label">總投注</div></div>
</div>
<div class="section"><h2>即將開賽</h2><table>
<tr><th>編號</th><th>主隊</th><th></th><th>客隊</th><th>聯賽</th><th>開賽</th><th>主勝</th><th>和</th><th>客勝</th></tr>
"""
    for m in matches[:15]:
        ko = (m["kickoff"] or "")[:16].replace("T", " ")
        hh = f'{m["had_h"]:.2f}' if m["had_h"] else "-"
        hd = f'{m["had_d"]:.2f}' if m["had_d"] else "-"
        ha = f'{m["had_a"]:.2f}' if m["had_a"] else "-"
        html += f'<tr><td>{m["match_id"]}</td><td>{m["home"]}</td><td style="color:#555">vs</td><td>{m["away"]}</td><td style="color:#888">{(m["tournament"] or "")[:12]}</td><td style="color:#888">{ko}</td><td class="odds">{hh}</td><td class="odds">{hd}</td><td class="odds">{ha}</td></tr>\n'

    html += "</table></div>"

    # Events log (from push)
    if push_events:
        html += '<div class="section"><h2>系統事件</h2><div class="event-log">'
        for e in push_events[:15]:
            ts = e.get("timestamp", "")[:19].replace("T", " ")
            desc = e.get("desc", "")[:80]
            html += f'<div class="event-row"><span class="event-ts">{ts}</span>{desc}</div>\n'
        html += "</div></div>"

    html += "</div>"

    # Agents tab
    emojis = {"ESTP": "👷", "ENFP": "💼", "ISTJ": "🏥", "INFJ": "📚"}
    html += '<div id="tab-agents" class="tab-content"><div class="agent-grid">'

    display_agents = push_agents if push_agents else [dict(a) for a in agents]
    for a in display_agents:
        name = a.get("name", "")
        mbti = a.get("mbti") or a.get("base_mbti", "")
        occ = a.get("role") or a.get("occupation", "")
        bal = a.get("balance", 10000)
        pnl = a.get("pnl") or a.get("total_pnl", 0)
        tb = a.get("total_bets", 0)
        tw = a.get("total_wins", 0)
        wr = round(tw / tb * 100, 1) if tb > 0 else 0
        energy = a.get("energy") or a.get("current_energy", 100)
        mood = a.get("mood", 0)
        if isinstance(a.get("emotions"), dict):
            mood = a["emotions"].get("mood", mood)
        conf = a.get("confidence", 0)
        if isinstance(a.get("emotions"), dict):
            conf = a["emotions"].get("confidence", conf)
        emoji = emojis.get(mbti, "👤")
        pnl_cls = "pos" if pnl >= 0 else "neg"
        pnl_sign = "+" if pnl >= 0 else ""

        html += f"""<div class="agent-card">
<div style="display:flex;align-items:center;gap:10px;margin-bottom:10px">
<span style="font-size:2em">{emoji}</span>
<div><div class="agent-name">{name}</div><div class="agent-meta">{mbti} | {occ}</div></div>
<div style="margin-left:auto;text-align:right">
<div style="font-size:1.2em;font-weight:700;color:#d4af37">${bal:,.0f}</div>
<div class="{pnl_cls}" style="font-size:.85em">{pnl_sign}${pnl:,.0f}</div></div></div>
<div class="agent-stats">
<div class="agent-stat"><div class="v">{tb}</div><div class="l">下注</div></div>
<div class="agent-stat"><div class="v">{tw}</div><div class="l">勝</div></div>
<div class="agent-stat"><div class="v">{wr}%</div><div class="l">勝率</div></div>
<div class="agent-stat"><div class="v">{int(energy)}</div><div class="l">精力</div></div></div>
<div style="margin-top:10px;font-size:.75em;color:#666">
心情 <div class="emo-bar"><div class="emo-fill" style="width:{max(0,min(100,float(mood)*100))}%;background:#4fc3f7"></div></div>
自信 <div class="emo-bar"><div class="emo-fill" style="width:{max(0,min(100,float(conf)*100))}%;background:#81c784"></div></div></div></div>"""

    html += "</div></div>"

    # Upcoming tab
    html += '<div id="tab-upcoming" class="tab-content"><div class="section"><h2>所有未開賽賽事</h2><table>'
    html += '<tr><th>編號</th><th>主隊</th><th></th><th>客隊</th><th>聯賽</th><th>開賽</th><th>主勝</th><th>和</th><th>客勝</th></tr>'
    for m in matches:
        ko = (m["kickoff"] or "")[:16].replace("T", " ")
        hh = f'{m["had_h"]:.2f}' if m["had_h"] else "-"
        hd = f'{m["had_d"]:.2f}' if m["had_d"] else "-"
        ha = f'{m["had_a"]:.2f}' if m["had_a"] else "-"
        html += f'<tr><td>{m["match_id"]}</td><td>{m["home"]}</td><td style="color:#555">vs</td><td>{m["away"]}</td><td style="color:#888">{(m["tournament"] or "")[:12]}</td><td style="color:#888">{ko}</td><td class="odds">{hh}</td><td class="odds">{hd}</td><td class="odds">{ha}</td></tr>\n'
    html += "</table></div></div>"

    # Finished tab
    html += '<div id="tab-finished" class="tab-content"><div class="section"><h2>已完結賽事</h2><table>'
    html += '<tr><th>編號</th><th>主隊</th><th>比分</th><th>客隊</th><th>聯賽</th><th>結果</th></tr>'
    for m in finished_matches:
        hg = m["home_goals"] if m["home_goals"] is not None else "?"
        ag = m["away_goals"] if m["away_goals"] is not None else "?"
        result = m["had_result"] or ""
        badge_cls = {"H": "badge-h", "D": "badge-d", "A": "badge-a"}.get(result, "")
        result_text = {"H": "主勝", "D": "和局", "A": "客勝"}.get(result, "-")
        html += f'<tr><td>{m["match_id"]}</td><td>{m["home"]}</td><td style="font-weight:700">{hg}:{ag}</td><td>{m["away"]}</td><td style="color:#888">{(m["tournament"] or "")[:12]}</td><td><span class="badge {badge_cls}">{result_text}</span></td></tr>\n'
    html += "</table></div></div>"

    # Footer + SSE auto-refresh script
    html += f"""
</div>
<div class="footer">
HKJC AI Betting Lab | 數據更新: {datetime.now().strftime('%Y-%m-%d %H:%M')} | 純展示用途<br>
&copy; 2026 AI Betting Lab
</div>
<script>
function showTab(name) {{
  document.querySelectorAll('.tab-content').forEach(el => el.classList.remove('active'));
  document.querySelectorAll('.tab').forEach(el => el.classList.remove('active'));
  document.getElementById('tab-' + name).classList.add('active');
  event.target.classList.add('active');
}}

// SSE 即時更新：收到 push 就刷新頁面
const es = new EventSource('/api/stream');
es.onmessage = function(e) {{
  try {{
    const d = JSON.parse(e.data);
    if (d.type === 'data_push') {{
      document.getElementById('sync-bar').innerHTML = '🟢 收到新數據，刷新中...';
      setTimeout(() => window.location.reload(), 500);
    }}
  }} catch(err) {{}}
}};
es.onerror = function() {{
  setTimeout(() => window.location.reload(), 5000);
}};
</script>
</body></html>"""

    return Response(html, content_type="text/html; charset=utf-8")


# ══════════════════════════════════════════════════════════════
#  啟動
# ══════════════════════════════════════════════════════════════

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    print()
    print("╔══════════════════════════════════════════════════╗")
    print("║     HKJC AI Betting Lab — Dashboard Server      ║")
    print("╠══════════════════════════════════════════════════╣")
    print(f"║  🌐 http://localhost:{port}                     ║")
    print(f"║  📡 POST /push (Bearer token)                  ║")
    print(f"║  📺 GET  /api/stream (SSE)                     ║")
    print(f"║  🔑 SECRET_KEY: {'已設定 ✅' if SECRET_KEY else '未設定 ⚠️ (任何人可推送)'}  ║")
    print("╚══════════════════════════════════════════════════╝")
    print()
    app.run(host="0.0.0.0", port=port, threaded=True)
